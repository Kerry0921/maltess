<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class 01 extends Controller
{
    //
}
